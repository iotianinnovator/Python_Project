
import turtle
import random
from alphabet import alphabet
from shape import *

myPen = turtle.Turtle()
myPen.hideturtle()
myPen.speed(10)
window = turtle.Screen()
window.bgcolor("black")
myPen.pensize(2)

def displayMessage(message,fontSize,color,x,y):
  myPen.color(color)
  message=message.upper()
  
  for character in message:
    if character in alphabet:
      letter=alphabet[character]
      myPen.penup()
      for dot in letter:
        myPen.goto(x + dot[0]*fontSize, y + dot[1]*fontSize)
        myPen.pendown()
        
      x += fontSize
      
    if character == " ":
      x += fontSize
    x += characterSpacing 

#Main Program Starts Here
fontSize = 30
characterSpacing = 5
fontColor = "#4286f4"

message = "HAPPY HOLI"
displayMessage(message,fontSize,fontColor,-190,0)

#left upper side
draw_star(myPen,'yellow',-320,100,20)
draw_star(myPen,'yellow',-300,125,20)
draw_star(myPen,'yellow',-280,150,20)
draw_star(myPen,'yellow',-260,175,20)
draw_star(myPen,'yellow',-240,200,20)
draw_star(myPen,'yellow',-220,225,20)
draw_star(myPen,'yellow',-200,250,20)
draw_star(myPen,'yellow',-180,275,20)

#right upper side
draw_star(myPen,'pink',320,100,20)
draw_star(myPen,'pink',300,125,20)
draw_star(myPen,'pink',280,150,20)
draw_star(myPen,'pink',260,175,20)
draw_star(myPen,'pink',240,200,20)
draw_star(myPen,'pink',220,225,20)
draw_star(myPen,'pink',200,250,20)
draw_star(myPen,'pink',180,275,20)

#left down side
draw_star(myPen,'green',-320,-100,20)
draw_star(myPen,'green',-300,-125,20)
draw_star(myPen,'green',-280,-150,20)
draw_star(myPen,'green',-260,-175,20)
draw_star(myPen,'green',-240,-200,20)
draw_star(myPen,'green',-220,-225,20)
draw_star(myPen,'green',-200,-250,20)
draw_star(myPen,'green',-180,-275,20)

#right down side 
draw_star(myPen,'red',320,-100,20)
draw_star(myPen,'red',300,-125,20)
draw_star(myPen,'red',280,-150,20)
draw_star(myPen,'red',260,-175,20)
draw_star(myPen,'red',240,-200,20)
draw_star(myPen,'red',220,-225,20)
draw_star(myPen,'red',200,-250,20)
draw_star(myPen,'red',180,-275,20)



